from django.shortcuts import render
import requests
import datetime

# Create your views here.

def index(request):
    city = None
    description = ""
    icon = ""
    temp = ""

    if request.method == 'POST' and 'city' in request.POST:
        city = request.POST['city']

    if city:
        appid ='67ce927a1187be1c94c9b44e96e69f55'
        URL='https://api.openweathermap.org/data/2.5/weather'
        PARAMS= {'q': city, 'appid': appid, 'units': 'metric'}
        
        r = requests.get(url=URL, params=PARAMS)
        res = r.json()

        if 'weather' in res and 'main' in res:
            description = res['weather'][0]['description']
            icon = res['weather'][0]['icon']
            temp = res['main']['temp']
        else:
            # Handle case when data is not available for the city
            description = "Weather data not available"
            icon = ""
            temp = ""

    else:
       city = 'Kolkata'  # Default city if no city is provided

    day = datetime.date.today()

    return render(request, 'weatherapp/index.html', {'description': description, 'icon': icon, 'temp': temp, 'day': day, 'city': city})
