from django.apps import AppConfig


class WaetherappConfig(AppConfig):
    name = 'waetherapp'
